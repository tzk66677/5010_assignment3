let angle = 0;      // Current rotation angle
let rotSpeed = 0;   // Rotation speed for continuous acceleration after 30 seconds

function setup() {
  createCanvas(600, 400);
  angleMode(RADIANS);
  ellipseMode(CENTER);
  noStroke();
}

function draw() {
  background(30);

  // Draw the Taiji symbol in the center of the canvas
  push();
  translate(width / 2, height / 2);
  rotate(angle);
  drawTaiji(100); // Outer circle radius is 100
  pop();

  // Determine the current stage based on frameCount for smooth transitions
  if (frameCount <= 300) {
    // Stage 0: First 5 seconds
    angle += 0.01;
  } else if (frameCount <= 600) {
    // Stage 1: 5 to 10 seconds
    angle += 0.02;
  } else if (frameCount <= 900) {
    // Stage 2: 10 to 15 seconds
    angle += 0.03;
  } else if (frameCount <= 1200) {
    // Stage 3: 15 to 20 seconds
    angle += 0.05;
  } else if (frameCount <= 1800) {
    // Stage 4: 20 to 30 seconds
    angle += 0.08;
  } else {
    // After 30 seconds, enter continuous acceleration stage
    if (frameCount === 1801) {
      // When first entering the continuous acceleration stage, initialize rotSpeed to the Stage 4 speed
      rotSpeed = 0.08;
    }
    rotSpeed += 0.0005;  // Increase the rotation acceleration each frame
    angle += rotSpeed;
  }
  
  // After 4 minutes (approximately 14400 frames), reset the animation to loop
  if (frameCount > 14400) {
    angle = 0;
    rotSpeed = 0;
    // Since frameCount is a built-in variable and cannot be reset, we simulate a reset by pausing and restarting the loop
    noLoop();
    setTimeout(() => {
      loop();
    }, 10);
  }
}

// Function to draw the Taiji symbol
// Parameter r is the outer circle radius
function drawTaiji(r) {
  // When the mouse is pressed, swap the black and white colors
  let primaryBlack = 0;
  let primaryWhite = 255;
  if (mouseIsPressed) {
    primaryBlack = 255;
    primaryWhite = 0;
  }
  
  push();
  // Draw the outer circle filled with primaryBlack
  fill(primaryBlack);
  ellipse(0, 0, r * 2, r * 2);
  
  // Draw the white semicircle (right side)
  fill(primaryWhite);
  arc(0, 0, r * 2, r * 2, -HALF_PI, HALF_PI, PIE);
  
  // Draw the large circle in the upper half (black)
  fill(primaryBlack);
  ellipse(0, -r / 2, r, r);
  
  // Draw the large circle in the lower half (white)
  fill(primaryWhite);
  ellipse(0, r / 2, r, r);
  
  // Draw a smaller circle in the upper half (white), size r/3
  fill(primaryWhite);
  ellipse(0, -r / 2, r / 3, r / 3);
  
  // Draw a smaller circle in the lower half (black), size r/3
  fill(primaryBlack);
  ellipse(0, r / 2, r / 3, r / 3);
  pop();
}
